function display_10_first_integers() {
    for (var i=0; i <= 10; i++) console.log("i = " + i);
}

console.log("*** 1st call ***");
display_10_first_integers();
console.log("*** 2nd call ***");
display_10_first_integers();
console.log("*** 3rd call ***");
display_10_first_integers();