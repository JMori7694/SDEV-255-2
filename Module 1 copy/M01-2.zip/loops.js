var i = 0;
while (i <= 5) {
    console.log("i = " + i);
    i++;
}