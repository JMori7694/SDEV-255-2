var a = 13;
var b = 56;
console.log("a = " + a);
console.log("b = " + b);
if (a == 12 || b > 50) 
    console.log("condition a == 12 || b > 50 is true");
else console.log("condition a == 12 || b > 50 is false");