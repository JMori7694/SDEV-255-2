var a = 13;
var b = 56;
console.log("a = " + a);
console.log("b = " + b);
if (a == 12) 
    console.log("condition a == 12 is true");
else {
    console.log("condition a == 12 is false");
    if (b > 50) console.log("condition b > 50 is true");
    else console.log("condition b > 50 is false");
}