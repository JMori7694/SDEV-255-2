var tab = new Array();
console.log(tab);