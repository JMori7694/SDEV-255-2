var tab = ["Element 1", "Element 2", "Element 3", "Element 4", "Element 5"];
console.log("tab = ", tab);
console.log("tab[0] = ", tab[0]);
console.log("tab[1] = ", tab[1]);
console.log("tab[2] = ", tab[2]);
console.log("tab[3] = ", tab[3]);
console.log("tab[4] = ", tab[4]);
console.log("tab[5] = ", tab[5]);