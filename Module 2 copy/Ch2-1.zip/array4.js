var tab = ["Element 1", "Element 2", "Element 3", "Element 4", "Element 5"];
console.log("Array before modification");
console.log("tab = ", tab);
tab[2] = "New element 3";
tab[3] = "New element 4";
console.log("Array after modification");
console.log("tab = ", tab);